package com.atguigu.shop.mappers;

import com.atguigu.shop.entities.Employee;
import tk.mybatis.mapper.common.Mapper;

public interface EmployeeMapper extends Mapper<Employee> {
}