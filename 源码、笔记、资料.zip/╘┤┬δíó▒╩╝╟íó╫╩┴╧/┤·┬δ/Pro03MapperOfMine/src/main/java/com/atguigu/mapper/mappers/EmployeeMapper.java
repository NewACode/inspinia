package com.atguigu.mapper.mappers;

import com.atguigu.mapper.entities.Employee;
import com.atguigu.mapper.mine_mappers.MyMapper;

public interface EmployeeMapper extends MyMapper<Employee> {

}