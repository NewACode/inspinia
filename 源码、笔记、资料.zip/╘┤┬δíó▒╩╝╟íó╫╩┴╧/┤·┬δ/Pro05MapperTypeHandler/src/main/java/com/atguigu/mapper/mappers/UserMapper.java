package com.atguigu.mapper.mappers;

import com.atguigu.mapper.entities.User;

import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {

}
