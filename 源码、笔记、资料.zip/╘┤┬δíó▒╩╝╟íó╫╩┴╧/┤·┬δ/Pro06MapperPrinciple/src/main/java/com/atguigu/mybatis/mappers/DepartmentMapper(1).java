package com.atguigu.mybatis.mappers;

import com.atguigu.mybatis.entities.Department;

import tk.mybatis.mapper.common.Mapper;

public interface DepartmentMapper extends Mapper<Department> {

}
